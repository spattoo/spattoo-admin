import { useMemo } from 'react';
import { useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { buildCreamWriting } from '../geometry/creamText.js';
import { writingPlaceAt, writingSurface, writingText } from '../geometry/surface.js';
import { planeHit, cylinderHit } from '../utils/raycasting.js';
import { useDragPlacement } from '../hooks/useDragPlacement.js';
import { creamMaterialProps, goldMaterialProps, silverMaterialProps, metallicCreamProps, GOLD_FINISH_COLOR, SILVER_FINISH_COLOR, PIPING_SOFTNESS_DEFAULT } from './CakeTier.jsx';

const DEG = Math.PI / 180;
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

// One cream-pen message piped onto a chosen cake surface. `writing.surface` selects where:
//   'top'   — flat on the cake top   (placed by offsetX/offsetZ, free-dragged on the top plane)
//   'board' — flat on the cake board (placed by boardX/boardZ,   free-dragged on the board plane)
//   'side'  — wrapped around the cake side (placed by sideAngle/sideY, dragged around & up the side)
// Drag mirrors DraggableTopSticker: grab disables orbit, the message follows the pointer on its
// surface, and a no-move press is treated as a tap → select.
export default function CreamWriting({
  writing, topY, topRadius, shape = 'round', width = 0, depth = 0, shp,
  tiers, boardRadius = 0, boardY = 0.1, boardShp,
  /* Where this message's HOST puts it, when it is written on an element rather than on the cake.
     Resolved by the canvas (only it knows what is on the tier) and handed in already shaped, so
     this renderer never learns what a rainbow is. */
  hostPath = null,
  onClick, onMove, onOrbitEnable, selected = false,
}) {
  const { camera, gl } = useThree();
  const thickness = writing?.thickness ?? 0.03;
  // Where this message sits — one resolution, shared with every other material a message can be
  // made of. See geometry/surface.js: the tier comes from the height, for every renderer at once.
  const {
    surface, fit, cakeBaseR, sideY, sideTier, sideRect, sideR, sideH,
    maxW, maxH, wrapRadius, minSideY, maxSideY, curve, host,
  } = writingSurface({ writing, tiers, topY, topRadius, shape, width, depth, boardRadius, hostPath });

  const geo = useMemo(() => {
    if (!writing?.text?.trim()) return null;
    const text = writingText(writing);   // shared with AcrylicWriting — see the note on writingText
    return buildCreamWriting({
      text, font: writing.font, thickness, maxW, maxH,
      lineGap: writing.lineSpacing ?? 1.4, letterSpacing: writing.letterSpacing ?? 0,
      curve, wrapRadius,
    });
  }, [writing?.text, writing?.uppercase, writing?.font, thickness, maxW, maxH, writing?.lineSpacing, writing?.letterSpacing, curve, wrapRadius]);

  // Side-drag vertical bounds (also used by the drag resolver below).
  /* ⚠️ THE DRAG SPANS THE WHOLE CAKE, and clamping it to one tier was a regression I introduced and
     had to take back. Dragging a message from one tier to another ALREADY WORKED — the tier was
     resolved from the height, so crossing a boundary picked up the new tier's radius on the way. I
     clamped it while adding the tier chooser, on the theory that a thumb should not change tiers by
     accident, and in doing so removed a capability bakers were already using. The chooser is worth
     having because an upper tier was not DISCOVERABLE, not because the drag was wrong. */
  // Drag-to-place: map the pointer ray to a per-surface placement patch; the press/drag/tap plumbing
  // and grabProps are shared (useDragPlacement). Called before the early return to satisfy hook rules.
  const { grabProps } = useDragPlacement({
    camera, gl, onMove, onClick, onOrbitEnable,
    // Intersecting stays here — it needs a camera. WHERE that lands is a rule, and the rule lives
    // in geometry/surface.js so the movable contract can ask it questions.
    resolve: (ray) => {
      const where = { surface, sideRect, sideWidth: sideTier?.width, minSideY, maxSideY,
                      shape: shp, boardShape: boardShp };
      /* ⚠️ A drag that crosses a tier boundary must WRITE the new tier back, or the stored `sideTier`
         and the height disagree and the next render snaps the message somewhere nobody put it. This
         is the seam between "choose a tier" and "drag between tiers": both end up saying the same
         thing. */
      if (surface === 'side' && !sideRect) return writingPlaceAt(where, cylinderHit(ray, sideR));
  if (surface === 'side') {
        // Rect side: intersect the front face plane (z = depth/2), drag in x & y.
        const t = new THREE.Vector3();
        return writingPlaceAt(where,
          ray.intersectPlane(new THREE.Plane(new THREE.Vector3(0, 0, 1), -(sideR)), t) ? t : null);
      }
      const planeY = surface === 'board' ? boardY : topY;
      return writingPlaceAt(where,
        planeHit(ray, new THREE.Plane(new THREE.Vector3(0, 1, 0), -planeY)));
    },
  });

  if (!geo) return null;

  const isGold       = writing.finish === 'gold';
  const isSilver     = writing.finish === 'silver';
  const color = writing.color ?? '#ffffff';
  // Metallic cream: a shiny, shimmery version of the picked cream colour (only when
  // on the plain "Colour" finish — gold/silver are their own metals).
  const isMetalCream = !isGold && !isSilver && !!writing.metallic;
  const isMetal      = isGold || isSilver || isMetalCream;
  const lift  = writing.lift ?? 0.02;
  const yaw   = (writing.yaw ?? 0) * DEG;

  // Resolved placement (per-surface coords, each with a sensible default).
  const ox        = surface === 'board' ? (writing.boardX ?? 0) : (writing.offsetX ?? 0);
  const oz        = surface === 'board' ? (writing.boardZ ?? (cakeBaseR + (boardRadius || cakeBaseR)) / 2) : (writing.offsetZ ?? 0);
  const sideAngle = writing.sideAngle ?? 0;

  // Grab proxy size (from the built geometry's extents).
  const bb = geo.boundingBox;
  const grabW = Math.max((bb.max.x - bb.min.x) + thickness * 3, thickness * 4);
  const grabH = Math.max((bb.max.y - bb.min.y) + thickness * 3, thickness * 4);

  // Emissive: cream lights up purple only when selected; metal finishes carry a constant
  // glow (so they read as metal without a strong env map) and brighten a touch when selected.
  // Selection highlight glows in the writing's OWN colour (never a fixed purple) — a
  // tinted emissive would shift saturated hues (green→teal, red→pink), so the picked
  // hex always renders true whether selected or not. (Same fix as the cream piping.)
  const emissive = isGold ? '#3a2a05' : isSilver ? '#23272d'
    : isMetalCream ? color
    : (selected ? color : '#000000');
  const emissiveIntensity = isGold || isSilver ? (selected ? 0.6 : 0.4)
    : isMetalCream ? (selected ? 0.22 : 0.12)   // a faint self-lit shimmer in its own colour
    : (selected ? 0.15 : 0);
  const metalProps = isGold ? goldMaterialProps(GOLD_FINISH_COLOR)
    : isSilver ? silverMaterialProps(SILVER_FINISH_COLOR)
    : isMetalCream ? metallicCreamProps(color)
    : null;
  const material = (
    <meshPhysicalMaterial
      {...(metalProps ?? creamMaterialProps(writing.softness ?? PIPING_SOFTNESS_DEFAULT, color))}
      emissive={emissive}
      emissiveIntensity={emissiveIntensity}
    />
  );
  const grabPlane = (z = 0.005) => (
    <mesh position={[0, 0, z]} {...grabProps}>
      <planeGeometry args={[grabW, grabH]} />
      <meshBasicMaterial transparent opacity={0} depthWrite={false}
          side={THREE.DoubleSide} /* or it is not a target from behind, and the decoration
          becomes ungrabbable the moment the cake is turned past it */ />
    </mesh>
  );

  // ── Side: geometry is already wrapped & vertical, centred on +Z. Rotate around Y
  // to the drag angle, raise to the drag height. ──────────────────────────────────
  /* ⚠️ A HOSTED MESSAGE STANDS IN ITS HOST'S PLANE, and the host says where that is. A rainbow is
     flat and set back from the cake's centre by its own `standoff`, so the line stands upright at
     the arch's centre and is pushed to the arch's face — stuck ON the fondant, not floating in
     front of it. `warpArc` has already bent the glyphs to the arch's sweep, so nothing here rotates
     them one at a time: the whole line is one upright plane, exactly like a baker pressing cut
     letters onto a rope.
     ⚠️ LIFTED BY THE ARCH'S RADIUS. `warpArc` leaves the bent line's CENTRE OF CURVATURE at
     `(0, -R)` in its own frame, so seating the group on the arch's centre would put the word in
     the middle of the hole. Raising it by the radius lands that centre on the arch's own.
     ⚠️ AND IT BELONGS HERE, AMONG THE RENDER BRANCHES. The first version of this went in beside
     an `if (surface === 'side')` that lives INSIDE the drag resolver — so it returned JSX as a
     drag placement, never ran, and the message fell through to the `top` branch and was drawn on
     the CAKE. It still looked bent and still tracked the band, because `writingSurface` had
     already handed over the arch's curve and size: everything about it was right except where it
     was. Reported in one line: *"text is not on rainbow. its on cake."* */
  if (surface === 'host' && host) {
    const face = host.face + thickness * 0.5 + 0.002;
    return (
      <group position={[host.centerX, host.centerY + host.radius, face]}>
        <mesh geometry={geo} castShadow>{material}</mesh>
        {grabPlane(bb.max.z + 0.01)}
      </group>
    );
  }
  if (surface === 'side' && !sideRect) {
    return (
      <group rotation={[0, sideAngle, 0]}>
        <group position={[0, sideY, 0]}>
          <mesh geometry={geo} castShadow>{material}</mesh>
          {/* tangent grab plane just in front of the wrapped text */}
          <mesh position={[0, 0, bb.max.z + 0.01]} {...grabProps}>
            <planeGeometry args={[grabW, grabH]} />
            <meshBasicMaterial transparent opacity={0} depthWrite={false}
          side={THREE.DoubleSide} /* or it is not a target from behind, and the decoration
          becomes ungrabbable the moment the cake is turned past it */ />
          </mesh>
        </group>
      </group>
    );
  }
  if (surface === 'side') {
    // Rect cake: flat decal on the front face (faces +Z, text already upright).
    return (
      <group position={[writing.offsetX ?? 0, sideY, sideR + lift]}>
        <mesh geometry={geo} castShadow>{material}</mesh>
        {grabPlane(bb.max.z + 0.01)}
      </group>
    );
  }

  // ── Top / Board: lay the XY text flat onto the horizontal plane. ────────────────
  const baseY = surface === 'board' ? boardY + 0.006 : topY + lift;
  return (
    <group position={[ox, baseY, oz]} rotation={[0, yaw, 0]}>
      <group rotation={[-Math.PI / 2, 0, 0]}>
        <mesh geometry={geo} castShadow>{material}</mesh>
        {grabPlane()}
      </group>
    </group>
  );
}
