/* ── The lens a take is filmed on ────────────────────────────────────────────────────────────────
 *
 * The designer's default is 42°, and the canvas already says why that is right for its job and
 * wrong for this one:
 *
 *   "The default (42°, close) is a portrait lens for a thumbnail — flattering, but it splays a
 *    cake's near bottom edge outward, which reads as the cake bulging at the base. Judging a SHAPE
 *    needs a long lens (small fov, camera pulled back) so the silhouette on screen is the
 *    silhouette, not the perspective."
 *
 * Filming is the same question as judging a shape. A long lens compresses perspective, stops the
 * near rim splaying, and is most of what "cinematic" means before anyone reaches for a grade.
 *
 * ⚠️ IT COSTS NOTHING AND CHANGES NOTHING ELSE. `FitCakeToView` recomputes its distance from
 * `camera.fov` every frame and GLIDES there, so narrowing the lens makes the camera dolly back on
 * its own, eased, and the cake stays the same size in frame. The move is free and it is the right
 * move: a dolly back on a longer lens is a shot, where a cut to a different focal length is a jump.
 *
 * ⚠️ AND IT IS A TAKE-ONLY CHANGE, RESTORED AFTERWARDS. The baker's own view is a contract — what
 * they approve is what the customer gets — so the lens the designer renders a cake on must not
 * quietly move because somebody filmed it once. The component that applies this saves the old fov
 * on mount and puts it back on unmount, the same bargain `sceneSnapshot` makes for the reel.
 *
 * ⚠️ PIXEL RATIO IS DELIBERATELY NOT TOUCHED HERE. Raising it would sharpen the capture and is the
 * obvious next idea — but `takePlan.js` exists because a loaded cake on an older phone already
 * cannot always hold 60fps, and a take that drops frames is worse than a take that is slightly soft.
 * That one needs measuring before it is offered, not assuming.
 */

/** The designer's everyday lens — a portrait focal length, flattering for a thumbnail. */
export const EDITOR_FOV = 42;

/** What a take is filmed on. Long enough to compress, short of the distortion-free-but-flat look. */
export const CINEMATIC_FOV = 28;

/** The range the panel offers: 20° is a very long lens, 42° is the designer's own. */
export const LENS_RANGE = Object.freeze({ min: 20, max: 42 });

/**
 * How much further back the camera must sit to frame the same subject at `fov` instead of `from`.
 *
 * Framing is governed by the half-angle, so the distance scales with `tan(from/2) / tan(fov/2)`.
 * At the default pair that is 1.54× — the compression you can see, expressed as the dolly you
 * cannot. Exported because it is the number worth knowing before choosing a lens, and because an
 * arithmetic claim in a comment is one nobody checks.
 */
export function lensDistanceFactor(fov, from = EDITOR_FOV) {
  const half = (deg) => Math.tan((Math.max(1, Math.min(179, Number(deg) || 0)) * Math.PI) / 360);
  return half(from) / half(fov);
}

/** Keep a lens inside what the panel can ask for, so a stray value cannot invert the projection. */
export function clampLens(fov) {
  const v = Number(fov);
  if (!Number.isFinite(v)) return CINEMATIC_FOV;
  return Math.min(LENS_RANGE.max, Math.max(LENS_RANGE.min, v));
}
